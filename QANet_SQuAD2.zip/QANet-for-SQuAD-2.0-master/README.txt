pip install spacy
pip install ujson

cd Baseline
python setup.py

python3 QANet_main.py --batch_size 10 --epochs 30 --with_cuda --use_ema